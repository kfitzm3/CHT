Seeed ILI9341 2.2 TFT+SD library

http://www.ebay.com/itm/Hot-sale-2-2-inch-Serial-SPI-TFT-Color-240X320-LCD-Module-ILI9341-Driver-IC-/360699426541?pt=LH_DefaultDomain_0&hash=item53fb5c76ed

Pinout:

(Arduino: TFT)

D4 :  RESET

D5 :  CS

D6 :  D/C

D7 :  LED

D11 : MOSI

D12 : MISO

D13 : SCK
